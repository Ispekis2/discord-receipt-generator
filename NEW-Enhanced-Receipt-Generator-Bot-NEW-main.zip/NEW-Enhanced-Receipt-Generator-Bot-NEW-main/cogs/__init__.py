# Cogs package initialization
"""
Command cogs for the Discord Receipt Generator Bot.
This package contains all the command cogs that handle user commands.
"""
