# UI package initialization
"""
UI components for the Discord Receipt Generator Bot.
This package contains UI components like modals, views, and buttons.
"""
