# Core package initialization
"""
Core functionality modules for the Discord Receipt Generator Bot.
This package contains the main business logic for receipt generation.
"""
