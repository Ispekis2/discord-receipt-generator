# Utils package initialization
"""
Utility modules for the Discord Receipt Generator Bot.
This package contains common utility functions and helpers used across the bot.
"""
